products = ["Apple", "Banana", "Cucumber", "Orange"]

products.each do |product|
  puts product
end
