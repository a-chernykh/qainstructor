products = ["Apple", "Banana", "Cucumber", "Orange"]

i = 0
while i < products.length
  product = products[i]
  puts product
  i = i + 1
end
