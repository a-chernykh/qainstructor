product = "Bananas"
if product != "Apples"
  puts "Not Apples, but still tasty"
end
