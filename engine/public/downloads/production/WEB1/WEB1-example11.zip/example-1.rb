product = "Apples"
if product == "Apples"
  puts "red"
end
