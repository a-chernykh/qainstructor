product = "Oranges"
case product
when "Apples"
  puts "red"
when "Bananas"
  puts "yellow"
when "Oranges"
  puts "orange"
else
  puts "unknown"
end
