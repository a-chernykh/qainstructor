product = "Oranges"
if product == "Apples"
  puts "red"
elsif product == "Bananas"
  puts "yellow"
elsif product == "Oranges"
  puts "orange"
else
  puts "unknown"
end
