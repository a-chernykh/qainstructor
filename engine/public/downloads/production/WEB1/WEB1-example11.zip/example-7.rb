product = "Bananas"
unless product == "Apples"
  puts "Not Apples, but still tasty"
end
