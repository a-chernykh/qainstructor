product = "Bananas"
if product == "Apples"
  puts "red"
else
  puts "Not Apples"
end
