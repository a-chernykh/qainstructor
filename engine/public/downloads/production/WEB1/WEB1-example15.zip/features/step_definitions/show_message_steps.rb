Given /^I am on the front page$/ do
  @browser.get('http://slow.sample.qainstructor.com')
end

When /^I click "([^\"]+)" link$/ do |text|
  link = @browser.find_element(:link_text, text)
  link.click
  sleep 3 # Can be removed after https://github.com/mozilla/geckodriver/issues/308 is fixed
end

Then /^I should see "([^\"]+)"$/ do |message|
  body = @browser.find_element(:tag_name, 'body')
  expect(body.text).to include message
end
