Given(/^I go to the google\.com$/) do
  @browser.get('http://google.com')
end
