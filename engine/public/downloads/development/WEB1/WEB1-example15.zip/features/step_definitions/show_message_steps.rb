Given /^I am on the front page$/ do
  @browser.get('http://slow.sample.dockerhost.dev')
end

When /^I click "([^\"]+)" link$/ do |text|
  link = @browser.find_element(:link_text, text)
  link.click
end

Then /^I should see "([^\"]+)"$/ do |message|
  body = @browser.find_element(:tag_name, 'body')
  expect(body.text).to include message
end
