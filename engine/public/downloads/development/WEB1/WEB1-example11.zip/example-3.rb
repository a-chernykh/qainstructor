product = "Bananas"
if product == "Apples"
  puts "red"
elsif product == "Bananas"
  puts "yellow"
else
  puts "unknown"
end
