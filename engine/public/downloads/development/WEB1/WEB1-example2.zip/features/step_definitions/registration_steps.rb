Given /^I am on the front page$/ do
  @browser.get 'http://app.sample.dockerhost.dev'
end

When /^I click "(.*)" button$/ do |button_name|
  @browser.find_element(:css, "input[value~=#{button_name}]").click
end
